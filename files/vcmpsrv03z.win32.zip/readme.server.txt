VC-MP windows server 0.3x.

Please see the vc-mp.chm help file for information
on running a windows server.

This server is beta software and is not recommended
to be run on large public game servers. Do so at your
own risk.

Note: There must be a config file at vcmp/config.ini,
Server looks for vcmp/config.ini to load.

Admin commands.

> First identify with the /admin (password) command.
> Press F5 ingame to show the scoreboard.
> Identify a player id you wish to kick, ban or both.
> To kick a player use /kick (playerid)
> Use /getip (playerid) to print a player's IP address.
> Use /ban IP.mask to prevent an IP from reconnecting.
> Ban IP.masks can use wildcards e.g. 24.105.0.* to be a class C network.