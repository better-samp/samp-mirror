// CAN'T REALLY GPL A BUNCH OF WHITESPACE.. OR CAN WE?
//---------------------------------------------------
//
// VC:MP Multiplayer Modification For GTA:VC
// Copyright 2004-2005 SA:MP Team
//
//----------------------------------------------------


//----------------------------------------------------
// EOF